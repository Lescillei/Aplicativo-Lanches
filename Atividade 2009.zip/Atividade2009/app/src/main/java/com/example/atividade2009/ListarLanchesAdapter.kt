package com.example.atividade2009

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.atividade2009.model.Lanche
import java.text.DecimalFormat

class ListarLanchesAdapter(private val lanches : List<Lanche>)
    : RecyclerView.Adapter<ListarLanchesAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nomeLanche : TextView = itemView.findViewById(R.id.nome_lanche)
        val precoLanche : TextView = itemView.findViewById(R.id.preco_lanche)
        val descricaoLanche : TextView = itemView.findViewById(R.id.descricao_lanche)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_lanche, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val lanches = lanches[position]
        val formatador = DecimalFormat("#,##.00")
        val precoFormatado = formatador.format(lanches.preco)

        holder.nomeLanche.text = lanches.nome
        holder.precoLanche.text = precoFormatado
        holder.descricaoLanche.text = lanches.descricao
    }


    override fun getItemCount(): Int = lanches.size

    }