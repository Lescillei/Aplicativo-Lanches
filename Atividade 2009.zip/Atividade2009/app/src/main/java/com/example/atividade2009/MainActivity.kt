package com.example.atividade2009

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.atividade2009.model.Lanche
import java.math.BigDecimal

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_constrait)

        val lanches = listOf(
            Lanche("Hamburguer", BigDecimal(15.99), "Hamburguer artesanal com queijo"),
            Lanche("Pizza", BigDecimal(39.90), "Pizza de mussarela"),
            Lanche("Coxinha", BigDecimal(5.50), "Coxinha de frango com catupiry")
        )

        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = ListarLanchesAdapter(lanches)
    }
}