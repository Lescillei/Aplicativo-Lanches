package com.example.atividade2009.model

import java.math.BigDecimal

data class Lanche (val nome: String, val preco: BigDecimal, val descricao: String) {
}